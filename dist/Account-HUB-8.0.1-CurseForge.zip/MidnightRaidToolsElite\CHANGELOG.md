# Changelog

## 8.0.1

- Updated the release package and metadata for a clean CurseForge upload
- Refined the current UI/header presentation and included the latest branding assets
- Bundled the latest fixes for Next Pull docking, portal detection, KeystoneLoot import, and panel polish

## 8.0.0

- Rebranded the addon UI to `Account-HUB`
- Added localized German and English UI text
- Reworked Mythic+, Great Vault, currencies, guild, and character snapshot panels
- Added KeystoneLoot import support for loot targeting
- Replaced the unstable MDT minimap overlay with a `Next Pull` panel
- Added manual next-pull controls, reset support, and detachable popout mode
- Improved season portal detection and dungeon item level display
